﻿#region Copyright (C) 2017-$year$  Starflash Studios
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License (Version 3.0)
// as published by the Free Software Foundation.
// 
// More information can be found here: https://www.gnu.org/licenses/gpl-3.0.en.html
#endregion

#region Using Directives

using System.Threading.Tasks;

#endregion

namespace $projname$;

public class Program {
	
    public static async Task Main( string[] Args ) {
    }

}